package com.capstone.project.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(
    name = "users",
    indexes = {
        @Index(name = "idx_users_email", columnList = "email", unique = true)
    }
)
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true)
    private String email;

    @Column(nullable = false)
    private String passwordHash;

    @Column(nullable = false)
    private String name;

    @Column(columnDefinition = "varchar(255) default ''")
    private String location = "";

    @Column(nullable = false)
    private boolean verified = false;

    @Column(nullable = false, updatable = false)
    private LocalDateTime createdAt = LocalDateTime.now();

    // ── Getters & Setters ────────────────────────────────────

    public Long          getId()                          { return id; }

    public String        getEmail()                       { return email; }
    public void          setEmail(String email)           { this.email = email; }

    public String        getPasswordHash()                { return passwordHash; }
    public void          setPasswordHash(String h)        { this.passwordHash = h; }

    public boolean       isVerified()                     { return verified; }
    public void          setVerified(boolean verified)    { this.verified = verified; }

    public String        getName()                        { return name; }
    public void          setName(String name)             { this.name = name; }

    public String        getLocation()                    { return location; }
    public void          setLocation(String location)     { this.location = location; }

    public LocalDateTime getCreatedAt()                   { return createdAt; }
    public void          setCreatedAt(LocalDateTime t)    { this.createdAt = t; }
}
